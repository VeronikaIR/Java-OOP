import java.text.NumberFormat;
import java.util.Random;

public class RandomNumber{


    public static void countAndCalculatePercentage(int times){

        int count1 = 0;
        int count2 = 0;
        int count3 = 0;

        Random rand = new Random();

        for(int i = 0; i < times; i++){

            double number = rand.nextDouble();

            if(number <= 0.2){
                count1++;
                continue;
            }
            else if(number <= 0.5){
                count2++;
                continue;
            }
           count3++;
        }

    double probabilityOfOne = (double)count1 / times;
    double probabilityOfTwo = (double)count2 / times;
    double probabilityOfThree = (double)count3 / times;

    NumberFormat numberFormat = NumberFormat.getPercentInstance();
    numberFormat.setMinimumFractionDigits(2);

    System.out.println("P(1) = " + numberFormat.format(probabilityOfOne));
    System.out.println("P(2) = " + numberFormat.format(probabilityOfTwo));
    System.out.println("P(3) = " + numberFormat.format(probabilityOfThree));
    }

    public static void main(String[] args) {

        Random rand = new Random();

        System.out.println("Calculated probabilities for 10 000 times:");
        countAndCalculatePercentage(10_000);

        System.out.println();
        System.out.println("Calculated probabilities for 60 000 times:");
        countAndCalculatePercentage(60_000);
    }
}
